function showDetail(vehicleId) {
    alert('You clicked on: ' + vehicleId);
    // Here you can expand this function to show more detailed content dynamically
    // For instance, opening a modal or redirecting to another page with more details
}
